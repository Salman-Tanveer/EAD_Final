import React from 'react';
import Recipie from './Recipie';
import RecipeForm from './RecipeForm';
import RecipeOptions from './RecipeOptions';

function App() {
  return (
    <>
   <Recipie />    


   </>

   );
}

export default App;
