import React from 'react'

function RecipeOptions() {
  return (
    <div>
    <button>View Recipes</button>
    <button>Add Recipe</button>
    <button>Update Recipe</button>
    <button>Delete Recipe</button>
    <button>Search Recipe</button>


    </div>
  )
}

export default RecipeOptions