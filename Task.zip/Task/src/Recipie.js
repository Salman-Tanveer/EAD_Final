import React from 'react'
import RecipeForm from './RecipeForm'

function Recipie() {
  return (
    <div>
        <h1>Recipie Managent System</h1> 
         <RecipeForm />
    </div>
    
    
    )
}

export default Recipie