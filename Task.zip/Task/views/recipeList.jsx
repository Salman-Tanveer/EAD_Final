import React from 'react'

function recipeList() {
  return (
    <div>recipeList</div>
  )
}

export default recipeList