import React from 'react'

function recipeUpdate() {
  return (
    <div>recipeUpdate</div>
  )
}

export default recipeUpdate