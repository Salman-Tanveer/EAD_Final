import React from 'react'

function recipeView() {
  return (
    <div>recipeView</div>
  )
}

export default recipeView